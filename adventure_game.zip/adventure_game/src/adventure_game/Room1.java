/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package adventure_game;
import java.*;
import java.util.*;
/**
 *
 * @author ahmed
 */
public class Room1 
{
    private int userIn;
    Scanner Keyboard = new Scanner(System.in);

    
    public Room1(int userIn) {
        this.userIn = userIn;
        Action1(userIn);
    }
    
    public Room1() {
        
    }

    public int getUserIn() {
        return userIn;
    }

    public void setUserIn(int userIn) {
        this.userIn = userIn;
    }
    
    
    
    public void Action1(int userIn)
    {
       switch (userIn)
       {
           case 1:
               printScenario2();
               userIn = Keyboard.nextInt();
               Action2(userIn);
               break;
               
           case 2:
               while (userIn == 2)
               {
                   System.out.println("You have successfully wasted 10 minutes!! you Freak!");
                   System.out.println("Pick your choice dumbass!");
                   userIn = Keyboard.nextInt();
                   Action1(userIn);
               }
               break;
           default:
               System.out.println("Wrong choice, you illitrate idiot!\n choose a correct choice!");
               userIn = Keyboard.nextInt();
               Action1(userIn);
               break;
               
       }
               
    }
    public void Action2(int userIn)
    {
        switch (userIn)
       {
           case 1:
               printScenario3();
               break;
       }
    }
    
        
    
    
    
    
    public void printScenario1()
    {
        System.out.println("You wake up in a dark room, tied to a chair.\n"
                + "You are able to free one arm, but the other is tied too\n"
                + "tight. Both legs are tied to the chair legs and cannot move.\n"
                + "You cannot see anything in the room, but your sense of smell\n"
                + " has picked up the aroma of flowers. You need to escape.\n"
                + "Do you:\n");
        
        System.out.println("1. Try to move and find something to free yourself");
        System.out.println("2. Wait for someone to come help");
        System.out.println("\ta. If you waited, you lose 10 minutes off the time and have to repick same options");
        System.out.println("\tb. If you move, pick a direction");
        
    }
    
    public void printScenario2()
    {
        System.out.println("\nWhere do you want to go?");
        System.out.println("1. Right");
        System.out.println("2. Left");
    }
    
    public void printScenario3()
    {
        System.out.println("The aroma of flowers has grown. You feel around and there are flowers in a glass vase. \n"
                + "Do you:");
        System.out.println("");
    }
        
}
